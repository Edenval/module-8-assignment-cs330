///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declare the global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();

    // initialize the texture collection
    for (int i = 0; i < 16; i++)
    {
        m_textureIDs[i].tag = "";
        m_textureIDs[i].ID = -1;
    }
    m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
    // clear the allocated memory
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
    // destroy the created OpenGL textures
    DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    if (m_loadedTextures >= 16)
        return false;
    int width = 0;
    int height = 0;
    int colorChannels = 0;
    GLuint textureID = 0;

    // indicate to always flip images vertically when loaded
    stbi_set_flip_vertically_on_load(true);

    // parse the image data from the specified image file
    unsigned char* image = stbi_load(
        filename,
        &width,
        &height,
        &colorChannels,
        0);

    // if the image was successfully read from the image file
    if (image)
    {
        std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        // if the loaded image is in RGB format
        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        // if the loaded image is in RGBA format, it supports transparency
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else
        {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
            stbi_image_free(image);
            glDeleteTextures(1, &textureID);
            return false;
        }

        // generate the texture mipmaps for mapping textures to lower resolutions
        glGenerateMipmap(GL_TEXTURE_2D);

        // free the image data from local memory
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

        // register the loaded texture and associate it with the special tag string
        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;

        return true;
    }

    std::cout << "Could not load image:" << filename << std::endl;

    // Error loading the image
    return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        // bind textures on corresponding texture units
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureID = m_textureIDs[index].ID;
            bFound = true;
        }
        else
            index++;
    }

    return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int textureSlot = -1;
    int index = 0;
    bool bFound = false;

    while ((index < m_loadedTextures) && (bFound == false))
    {
        if (m_textureIDs[index].tag.compare(tag) == 0)
        {
            textureSlot = index;
            bFound = true;
        }
        else
            index++;
    }

    return(textureSlot);
}

/***********************************************************
 * FindMaterial()
 * Locate a material in the scene by its tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    for (size_t i = 0; i < m_objectMaterials.size(); i++)
    {
        if (m_objectMaterials[i].tag == tag)
        {
            material = m_objectMaterials[i];
            return true;
        }
    }
    return false;
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    // variables for this method
    glm::mat4 modelView;
    glm::mat4 scale;
    glm::mat4 rotationX;
    glm::mat4 rotationY;
    glm::mat4 rotationZ;
    glm::mat4 translation;

    // set the scale value in the transform buffer
    scale = glm::scale(scaleXYZ);
    // set the rotation values in the transform buffer
    rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    // set the translation value in the transform buffer
    translation = glm::translate(positionXYZ);

    modelView = translation * rotationX * rotationY * rotationZ * scale;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    // variables for this method
    glm::vec4 currentColor;

    currentColor.r = redColorValue;
    currentColor.g = greenColorValue;
    currentColor.b = blueColorValue;
    currentColor.a = alphaValue;

    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
    std::string textureTag)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, true);

        int textureID = -1;
        textureID = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (NULL != m_pShaderManager)
    {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 * SetShaderMaterial()
 * Send the selected material settings to the fragment shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    OBJECT_MATERIAL material;
    if (m_pShaderManager != NULL && FindMaterial(materialTag, material))
    {
        m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
        m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
        m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", material.shininess);
    }
}

/***********************************************************
 * LoadSceneTextures()
 * Existing project textures are reused for the furniture,
 * books, lamp, and tray. Keep all paths relative to the
 * Visual Studio project folder.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
    CreateGLTexture("../../Utilities/textures/desktop_wood.jpg", "wood");
    CreateGLTexture("../../Utilities/textures/brushed_steel.jpg", "metal");
    CreateGLTexture("../../Utilities/textures/warm_gold.jpg", "gold");
    CreateGLTexture("../../Utilities/textures/desktop_wall.jpg", "wall");
    BindGLTextures();
}

/***********************************************************
 * DefineObjectMaterials()
 * Material highlights differ for metal, paper, leaves, etc.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    m_objectMaterials.clear();
    OBJECT_MATERIAL material;

    material.tag = "matte";
    material.ambientColor = glm::vec3(1.0f);
    material.ambientStrength = 0.20f;
    material.diffuseColor = glm::vec3(0.92f);
    material.specularColor = glm::vec3(0.08f);
    material.shininess = 0.10f;
    m_objectMaterials.push_back(material);

    material.tag = "ceramic";
    material.ambientStrength = 0.18f;
    material.diffuseColor = glm::vec3(0.88f);
    material.specularColor = glm::vec3(0.28f);
    material.shininess = 0.36f;
    m_objectMaterials.push_back(material);

    material.tag = "glass";
    material.ambientStrength = 0.12f;
    material.diffuseColor = glm::vec3(0.84f);
    material.specularColor = glm::vec3(0.74f);
    material.shininess = 0.72f;
    m_objectMaterials.push_back(material);

    material.tag = "metal";
    material.ambientStrength = 0.15f;
    material.diffuseColor = glm::vec3(0.76f);
    material.specularColor = glm::vec3(0.86f);
    material.shininess = 0.72f;
    m_objectMaterials.push_back(material);

    material.tag = "leaf";
    material.ambientStrength = 0.32f;
    material.diffuseColor = glm::vec3(0.90f);
    material.specularColor = glm::vec3(0.12f);
    material.shininess = 0.12f;
    m_objectMaterials.push_back(material);
}

/***********************************************************
 * SetupSceneLights()
 * Warm light echoes the lamp in the photo; a neutral fill
 * light keeps the dark side of the plant and books visible.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    if (m_pShaderManager == nullptr)
        return;

    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // Warm lamp light from the left side of the still life.
    m_pShaderManager->setVec3Value("lightSources[0].position", -4.6f, 5.4f, 1.2f);
    m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.05f, 0.04f, 0.03f);
    m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.70f, 0.61f, 0.49f);
    m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.72f, 0.60f, 0.45f);
    m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 18.0f);
    m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.15f);

    // Soft neutral fill from the front-right to keep objects readable.
    m_pShaderManager->setVec3Value("lightSources[1].position", 4.2f, 4.0f, 7.8f);
    m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.012f, 0.012f, 0.014f);
    m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.38f, 0.40f, 0.42f);
    m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.10f, 0.11f, 0.12f);
    m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 12.0f);
    m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.05f);

    // Set remaining shader light slots to zero.
    for (int i = 2; i < 4; i++)
    {
        std::string prefix = "lightSources[" + std::to_string(i) + "].";
        m_pShaderManager->setVec3Value((prefix + "position").c_str(), 0.0f, 0.0f, 0.0f);
        m_pShaderManager->setVec3Value((prefix + "ambientColor").c_str(), 0.0f, 0.0f, 0.0f);
        m_pShaderManager->setVec3Value((prefix + "diffuseColor").c_str(), 0.0f, 0.0f, 0.0f);
        m_pShaderManager->setVec3Value((prefix + "specularColor").c_str(), 0.0f, 0.0f, 0.0f);
        m_pShaderManager->setFloatValue((prefix + "focalStrength").c_str(), 1.0f);
        m_pShaderManager->setFloatValue((prefix + "specularIntensity").c_str(), 0.0f);
    }
}

/***********************************************************
 * PrepareScene()
 * Each primitive mesh is loaded once and reused in the scene.
 ***********************************************************/
void SceneManager::PrepareScene()
{
    DefineObjectMaterials();
    LoadSceneTextures();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
    m_basicMeshes->LoadTorusMesh();
    SetupSceneLights();
}

/***********************************************************
 * DrawPart()
 * Reuses the same transformation/material setup for all
 * parts. This keeps RenderScene easy to adjust and extend.
 ***********************************************************/
void SceneManager::DrawPart(const std::string& mesh,
    const glm::vec3& position, const glm::vec3& size,
    const glm::vec3& rotation, const glm::vec4& color,
    const std::string& material, const std::string& texture)
{
    SetTransformations(size, rotation.x, rotation.y, rotation.z, position);
    SetShaderMaterial(material);
    SetShaderColor(color.r, color.g, color.b, color.a);
    SetTextureUVScale(1.0f, 1.0f);
    if (!texture.empty() && FindTextureSlot(texture) >= 0)
        SetShaderTexture(texture);

    if (mesh == "box") m_basicMeshes->DrawBoxMesh();
    else if (mesh == "plane") m_basicMeshes->DrawPlaneMesh();
    else if (mesh == "cylinder") m_basicMeshes->DrawCylinderMesh();
    else if (mesh == "open_cylinder") m_basicMeshes->DrawCylinderMesh(false, true, true);
    else if (mesh == "sleeve") m_basicMeshes->DrawCylinderMesh(false, false, true);
    else if (mesh == "cone") m_basicMeshes->DrawConeMesh();
    else if (mesh == "sphere") m_basicMeshes->DrawSphereMesh();
    else if (mesh == "tapered") m_basicMeshes->DrawTaperedCylinderMesh();
    else if (mesh == "torus") m_basicMeshes->DrawTorusMesh();
}

/***********************************************************
 * RenderScene()
 * A simplified desktop still life from the chosen photograph:
 * lamp (back left), books with coffee cup (front left),
 * plant (back right), and gold snack plate (front right).
 ***********************************************************/
void SceneManager::RenderScene()
{
    const glm::vec3 noRotation(0.0f);

    // Desk and background wall.
    DrawPart("plane", { 0.0f, 0.0f, 0.0f }, { 13.0f, 1.0f, 10.0f },
        noRotation, { 0.79f, 0.76f, 0.71f, 1.0f }, "matte");
    DrawPart("plane", { 0.0f, 4.7f, -4.8f }, { 13.0f, 1.0f, 8.6f },
        { 90.0f, 0.0f, 0.0f }, { 0.86f, 0.81f, 0.73f, 1.0f }, "matte", "wall");

    // Low, subtle contact shadows make the objects feel less detached.
    DrawPart("cylinder", { -2.35f, 0.006f, 1.15f }, { 2.53f, 0.012f, 1.84f },
        noRotation, { 0.19f, 0.17f, 0.15f, 0.19f }, "matte");
    DrawPart("cylinder", { 1.78f, 0.006f, -0.65f }, { 1.18f, 0.012f, 1.10f },
        noRotation, { 0.19f, 0.17f, 0.15f, 0.16f }, "matte");
    DrawPart("cylinder", { 3.78f, 0.006f, 2.65f }, { 2.10f, 0.012f, 1.85f },
        noRotation, { 0.19f, 0.17f, 0.15f, 0.15f }, "matte");

    // Stacked books with individual covers and cream page blocks.
    DrawPart("box", { -2.55f, 0.17f, 1.00f }, { 4.50f, 0.18f, 3.05f },
        { 0.0f, -11.0f, 0.0f }, { 0.30f, 0.25f, 0.22f, 1.0f }, "matte", "wood");
    DrawPart("box", { -2.55f, 0.29f, 1.00f }, { 4.33f, 0.17f, 2.88f },
        { 0.0f, -11.0f, 0.0f }, { 0.79f, 0.76f, 0.68f, 1.0f }, "matte");
    DrawPart("box", { -2.55f, 0.42f, 1.00f }, { 4.52f, 0.07f, 3.04f },
        { 0.0f, -11.0f, 0.0f }, { 0.37f, 0.33f, 0.29f, 1.0f }, "matte");

    DrawPart("box", { -2.18f, 0.51f, 1.24f }, { 4.03f, 0.12f, 2.67f },
        { 0.0f, 6.0f, 0.0f }, { 0.75f, 0.71f, 0.62f, 1.0f }, "matte");
    DrawPart("box", { -2.18f, 0.62f, 1.24f }, { 4.20f, 0.08f, 2.83f },
        { 0.0f, 6.0f, 0.0f }, { 0.93f, 0.88f, 0.78f, 1.0f }, "matte");

    DrawPart("box", { -2.52f, 0.69f, 1.50f }, { 3.88f, 0.12f, 2.55f },
        { 0.0f, -3.0f, 0.0f }, { 0.76f, 0.73f, 0.66f, 1.0f }, "matte");
    DrawPart("box", { -2.52f, 0.81f, 1.50f }, { 4.00f, 0.09f, 2.65f },
        { 0.0f, -3.0f, 0.0f }, { 0.93f, 0.89f, 0.82f, 1.0f }, "matte");

    // A paper notebook and a few visible page edges on the book stack.
    DrawPart("box", { -2.70f, 0.91f, 1.50f }, { 3.43f, 0.09f, 2.35f },
        { 0.0f, -3.0f, 0.0f }, { 0.96f, 0.94f, 0.89f, 1.0f }, "matte");
    DrawPart("box", { -2.70f, 0.97f, 1.50f }, { 0.035f, 0.015f, 2.36f },
        { 0.0f, -3.0f, 0.0f }, { 0.69f, 0.66f, 0.60f, 1.0f }, "matte");
    for (int i = 0; i < 3; ++i)
    {
        DrawPart("box", { -2.52f, 0.24f + 0.045f * i, 2.47f },
            { 3.76f, 0.012f, 0.018f }, { 0.0f, -11.0f, 0.0f },
            { 0.64f, 0.61f, 0.56f, 1.0f }, "matte");
    }

    // Lamp with a taller rectangular fabric shade and a wider metal base.
    // Its straight-edged shade follows the silhouette in the reference photo.
    DrawPart("cylinder", { -4.95f, 0.045f, -1.50f }, { 0.70f, 0.09f, 0.70f },
        noRotation, { 0.61f, 0.60f, 0.57f, 1.0f }, "metal", "metal");
    DrawPart("tapered", { -4.95f, 0.12f, -1.50f }, { 0.53f, 1.63f, 0.53f },
        noRotation, { 0.76f, 0.75f, 0.72f, 1.0f }, "metal", "metal");
    DrawPart("tapered", { -4.95f, 1.70f, -1.50f }, { 0.22f, 1.25f, 0.22f },
        noRotation, { 0.79f, 0.78f, 0.74f, 1.0f }, "metal", "metal");
    DrawPart("cylinder", { -4.95f, 2.89f, -1.50f }, { 0.20f, 0.16f, 0.20f },
        noRotation, { 0.72f, 0.70f, 0.66f, 1.0f }, "metal", "metal");
    DrawPart("box", { -4.95f, 4.05f, -1.50f }, { 3.67f, 2.45f, 2.30f },
        noRotation, { 0.97f, 0.95f, 0.90f, 1.0f }, "matte");
    DrawPart("box", { -4.95f, 2.835f, -1.50f }, { 3.71f, 0.035f, 2.34f },
        noRotation, { 0.89f, 0.86f, 0.81f, 1.0f }, "matte");

    // Turn the flowerpot so its opening is wider than its base. This
    // matches the ceramic planter in the photograph more closely.
    DrawPart("tapered", { 1.75f, 1.62f, -0.65f }, { 1.05f, 1.55f, 1.05f },
        { 180.0f, 0.0f, 0.0f }, { 0.82f, 0.77f, 0.68f, 1.0f }, "ceramic");
    DrawPart("cylinder", { 1.75f, 1.62f, -0.65f }, { 0.99f, 0.075f, 0.99f },
        noRotation, { 0.21f, 0.19f, 0.15f, 1.0f }, "matte");
    DrawPart("torus", { 1.75f, 1.69f, -0.65f }, { 1.02f, 1.02f, 0.07f },
        { 90.0f, 0.0f, 0.0f }, { 0.82f, 0.77f, 0.69f, 1.0f }, "ceramic");

    // Create plant leaves using flattened spheres.
    const glm::vec3 leafCenters[] = {
        {1.75f, 2.43f, -0.68f}, {1.22f, 2.34f, -0.55f},
        {2.24f, 2.36f, -0.58f}, {1.36f, 2.39f, -1.03f},
        {2.08f, 2.39f, -0.17f}, {1.54f, 2.66f, -0.44f},
        {2.02f, 2.62f, -0.91f}, {0.91f, 2.16f, -0.33f},
        {2.59f, 2.13f, -0.98f}, {1.20f, 2.23f, -0.93f},
        {2.29f, 2.21f, -0.34f}, {1.83f, 2.84f, -0.46f}
    };
    const float leafAngles[] = {
        -7.0f, 43.0f, -42.0f, 30.0f, -34.0f, 18.0f,
        -19.0f, 61.0f, -57.0f, 49.0f, -51.0f, 6.0f
    };
    for (int i = 0; i < 12; ++i)
    {
        const glm::vec4 leafGreen = (i % 3 == 0)
            ? glm::vec4(0.29f, 0.46f, 0.22f, 1.0f)
            : (i % 3 == 1)
            ? glm::vec4(0.36f, 0.54f, 0.23f, 1.0f)
            : glm::vec4(0.24f, 0.41f, 0.18f, 1.0f);
        DrawPart("sphere", leafCenters[i], { 0.31f, 0.74f, 0.095f },
            { 13.0f, 14.0f * i, leafAngles[i] }, leafGreen, "leaf");
    }

    // Two upright books sit behind the plant near the right edge.
    DrawPart("box", { 5.02f, 1.36f, -1.35f }, { 0.52f, 2.72f, 1.30f },
        noRotation, { 0.16f, 0.16f, 0.17f, 1.0f }, "matte");
    DrawPart("box", { 5.62f, 1.48f, -1.35f }, { 0.64f, 2.96f, 1.36f },
        noRotation, { 0.61f, 0.43f, 0.20f, 1.0f }, "matte");

    // Gold plate, shallow raised edge, and chocolate pieces.
    DrawPart("cylinder", { 3.78f, 0.035f, 2.65f }, { 2.04f, 0.08f, 1.76f },
        noRotation, { 0.80f, 0.60f, 0.25f, 1.0f }, "metal", "gold");
    DrawPart("torus", { 3.78f, 0.12f, 2.65f }, { 1.93f, 1.64f, 0.11f },
        { 90.0f, 0.0f, 0.0f }, { 0.86f, 0.62f, 0.24f, 1.0f }, "metal", "gold");
    DrawPart("box", { 3.25f, 0.18f, 2.26f }, { 0.52f, 0.26f, 0.50f },
        { 0.0f, 16.0f, 0.0f }, { 0.26f, 0.15f, 0.09f, 1.0f }, "matte");
    DrawPart("box", { 4.10f, 0.18f, 2.85f }, { 0.48f, 0.28f, 0.46f },
        { 0.0f, -12.0f, 0.0f }, { 0.32f, 0.18f, 0.10f, 1.0f }, "matte");
    DrawPart("box", { 3.58f, 0.17f, 3.37f }, { 0.38f, 0.25f, 0.39f },
        { 0.0f, 20.0f, 0.0f }, { 0.23f, 0.13f, 0.08f, 1.0f }, "matte");
    DrawPart("box", { 4.49f, 0.12f, 2.47f }, { 0.12f, 0.08f, 0.14f },
        { 0.0f, 18.0f, 0.0f }, { 0.22f, 0.13f, 0.08f, 1.0f }, "matte");
    DrawPart("box", { 2.93f, 0.12f, 3.08f }, { 0.13f, 0.07f, 0.12f },
        { 0.0f, 9.0f, 0.0f }, { 0.22f, 0.13f, 0.08f, 1.0f }, "matte");

    // Add coffee to the bottom of the glass.
    const glm::vec3 cupBase(-2.76f, 1.04f, 1.72f);
    m_pShaderManager->setBoolValue(g_UseLightingName, false);

    // A small amount of coffee sits in the lower third of the glass.
    // This cylinder has its base at Y = 0 in the ShapeMeshes geometry.
    DrawPart("cylinder", { cupBase.x, cupBase.y + 0.035f, cupBase.z },
        { 0.72f, 0.33f, 0.72f }, noRotation,
        { 0.45f, 0.27f, 0.16f, 0.76f }, "matte");

    // Transparent objects are rendered after the coffee.
    glDepthMask(GL_FALSE);

    // An open sleeve gives the cup clear walls without a solid top.
    // The neutral gray tint is intentionally subtle, not bright white.
    DrawPart("sleeve", cupBase, { 0.84f, 1.12f, 0.84f }, noRotation,
        { 0.54f, 0.52f, 0.49f, 0.16f }, "glass");

    // Narrow horizontal rings make the top lip and base readable.
    DrawPart("torus", { cupBase.x, cupBase.y + 1.12f, cupBase.z },
        { 0.84f, 0.84f, 0.11f }, { 90.0f, 0.0f, 0.0f },
        { 0.50f, 0.49f, 0.46f, 0.36f }, "glass");
    DrawPart("torus", { cupBase.x, cupBase.y + 0.04f, cupBase.z },
        { 0.81f, 0.81f, 0.09f }, { 90.0f, 0.0f, 0.0f },
        { 0.50f, 0.48f, 0.44f, 0.21f }, "glass");

    // The handle sits upright, with its left edge inside the cup wall.
    DrawPart("torus", { -1.83f, 1.57f, cupBase.z },
        { 0.36f, 0.40f, 0.13f }, noRotation,
        { 0.53f, 0.51f, 0.48f, 0.35f }, "glass");

    // Return to the normal render state for the next frame.
    glDepthMask(GL_TRUE);
    m_pShaderManager->setBoolValue(g_UseLightingName, true);
}
