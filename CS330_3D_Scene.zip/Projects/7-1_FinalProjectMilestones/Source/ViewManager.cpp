
///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// declaration of the global variables and defines
namespace
{
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;

    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    // camera
    Camera* g_pCamera = nullptr;

    // mouse movement variables
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // frame timing
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    bool bOrthographicProjection = false;
    bool gToggleKeyHeld = false;
}

/***********************************************************
 * ViewManager()
 *
 * Constructor for the ViewManager class.
 ***********************************************************/
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = NULL;

    g_pCamera = new Camera();

    // initial camera settings
    g_pCamera->Position = glm::vec3(-0.35f, 3.15f, 11.85f);
    g_pCamera->Yaw = -90.0f;
    g_pCamera->Pitch = -10.0f;
    g_pCamera->Zoom = 44.0f;

    g_pCamera->ProcessMouseMovement(0.0f, 0.0f);
}

/***********************************************************
 * ~ViewManager()
 *
 * Destructor for the ViewManager class.
 ***********************************************************/
ViewManager::~ViewManager()
{
    m_pShaderManager = NULL;
    m_pWindow = NULL;

    if (g_pCamera != NULL)
    {
        delete g_pCamera;
        g_pCamera = NULL;
    }
}

/***********************************************************
 * CreateDisplayWindow()
 *
 * Creates the OpenGL display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
    const char* windowTitle)
{
    GLFWwindow* window = nullptr;

    window = glfwCreateWindow(
        WINDOW_WIDTH,
        WINDOW_HEIGHT,
        windowTitle,
        NULL,
        NULL);

    if (window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return NULL;
    }

    glfwMakeContextCurrent(window);

    // mouse movement
    glfwSetCursorPosCallback(
        window,
        &ViewManager::Mouse_Position_Callback);

    // mouse scroll
    glfwSetScrollCallback(
        window,
        &ViewManager::Mouse_Scroll_Callback);

    // enable blending
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    m_pWindow = window;

    return window;
}

/***********************************************************
 * Mouse_Position_Callback()
 *
 * Rotates the camera while the right mouse button is held.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
    GLFWwindow* window,
    double xMousePos,
    double yMousePos)
{
    if (g_pCamera == nullptr)
    {
        return;
    }

    if (glfwGetMouseButton(
        window, GLFW_MOUSE_BUTTON_RIGHT) != GLFW_PRESS)
    {
        gFirstMouse = true;
        return;
    }

    if (gFirstMouse)
    {
        gLastX = static_cast<float>(xMousePos);
        gLastY = static_cast<float>(yMousePos);
        gFirstMouse = false;
    }

    float xOffset =
        static_cast<float>(xMousePos) - gLastX;

    float yOffset =
        gLastY - static_cast<float>(yMousePos);

    gLastX = static_cast<float>(xMousePos);
    gLastY = static_cast<float>(yMousePos);

    g_pCamera->ProcessMouseMovement(
        xOffset,
        yOffset);
}

/***********************************************************
 * Mouse_Scroll_Callback()
 *
 * Adjusts the camera zoom using the mouse scroll wheel.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(
    GLFWwindow* window,
    double xOffset,
    double yOffset)
{
    if (g_pCamera == nullptr)
    {
        return;
    }

    // Adjust camera movement speed using the scroll wheel.
    g_pCamera->MovementSpeed += static_cast<float>(yOffset) * 0.5f;
    if (g_pCamera->MovementSpeed < 0.5f) g_pCamera->MovementSpeed = 0.5f;
    if (g_pCamera->MovementSpeed > 20.0f) g_pCamera->MovementSpeed = 20.0f;

}

/***********************************************************
 * ProcessKeyboardEvents()
 *
 * Processes keyboard input for camera movement.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
    if (glfwGetKey(
        m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(m_pWindow, true);
    }

    if (g_pCamera == nullptr)
    {
        return;
    }

    // Press P once to switch between perspective and orthographic views.
    bool togglePressed = (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS);
    if (togglePressed && !gToggleKeyHeld)
    {
        bOrthographicProjection = !bOrthographicProjection;
        std::cout << (bOrthographicProjection ? "Orthographic view" : "Perspective view") << std::endl;
    }
    gToggleKeyHeld = togglePressed;

    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
    }

    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
    {
        g_pCamera->ProcessKeyboard(UP, gDeltaTime);
    }
}

/***********************************************************
 * PrepareSceneView()
 *
 * Prepares the camera view and projection matrices.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
    glm::mat4 view;
    glm::mat4 projection;

    // update frame time
    float currentFrame =
        static_cast<float>(glfwGetTime());

    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    // process keyboard input
    ProcessKeyboardEvents();

    // get the camera view matrix
    view = g_pCamera->GetViewMatrix();

    // Use the current framebuffer size so resizing does not stretch objects.
    int framebufferWidth = WINDOW_WIDTH;
    int framebufferHeight = WINDOW_HEIGHT;
    glfwGetFramebufferSize(m_pWindow, &framebufferWidth, &framebufferHeight);
    if (framebufferWidth < 1) framebufferWidth = 1;
    if (framebufferHeight < 1) framebufferHeight = 1;
    glViewport(0, 0, framebufferWidth, framebufferHeight);
    float aspect = static_cast<float>(framebufferWidth) / framebufferHeight;

    // Projection changes without moving or rotating the camera.
    if (bOrthographicProjection)
    {
        const float extent = 8.5f;
        projection = glm::ortho(-extent * aspect, extent * aspect,
            -extent, extent, 0.1f, 100.0f);
    }
    else
    {
        projection = glm::perspective(glm::radians(g_pCamera->Zoom),
            aspect, 0.1f, 100.0f);
    }

    if (m_pShaderManager != NULL)
    {
        // pass view and projection to the shader
        m_pShaderManager->setMat4Value(
            g_ViewName, view);

        m_pShaderManager->setMat4Value(
            g_ProjectionName, projection);

        // send camera position to shader
        m_pShaderManager->setVec3Value(
            "viewPosition",
            g_pCamera->Position);
    }
}
