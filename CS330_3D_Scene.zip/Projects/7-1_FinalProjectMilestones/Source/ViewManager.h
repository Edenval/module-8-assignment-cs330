
///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h"

class ViewManager
{
public:
    // constructor
    ViewManager(ShaderManager* pShaderManager);

    // destructor
    ~ViewManager();

    // mouse movement callback
    static void Mouse_Position_Callback(
        GLFWwindow* window,
        double xMousePos,
        double yMousePos);

    // mouse scroll callback
    static void Mouse_Scroll_Callback(
        GLFWwindow* window,
        double xOffset,
        double yOffset);

private:
    // shader manager
    ShaderManager* m_pShaderManager;

    // active display window
    GLFWwindow* m_pWindow;

    // keyboard input processing
    void ProcessKeyboardEvents();

public:
    // create the display window
    GLFWwindow* CreateDisplayWindow(
        const char* windowTitle);

    // prepare camera view and projection
    void PrepareSceneView();
};
