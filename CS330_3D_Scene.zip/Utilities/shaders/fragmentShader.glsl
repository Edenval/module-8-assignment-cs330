#version 440 core

struct Material
{
    vec3 ambientColor;
    float ambientStrength;
    vec3 diffuseColor;
    vec3 specularColor;
    float shininess;
};

struct LightSource
{
    vec3 position;
    vec3 ambientColor;
    vec3 diffuseColor;
    vec3 specularColor;
    float focalStrength;
    float specularIntensity;
};

#define TOTAL_LIGHTS 4

in vec3 fragmentPosition;
in vec3 fragmentVertexNormal;
in vec2 fragmentTextureCoordinate;

out vec4 outFragmentColor;

uniform bool bUseTexture = false;
uniform bool bUseLighting = false;
uniform vec4 objectColor = vec4(1.0);
uniform sampler2D objectTexture;
uniform vec3 viewPosition;
uniform vec2 UVscale = vec2(1.0, 1.0);
uniform LightSource lightSources[TOTAL_LIGHTS];
uniform Material material;

void main()
{
    vec4 surfaceColor = objectColor;
    if (bUseTexture)
    {
        surfaceColor = texture(objectTexture,
                               fragmentTextureCoordinate * UVscale);
    }

    if (!bUseLighting)
    {
        outFragmentColor = surfaceColor;
        return;
    }

    vec3 normal = normalize(fragmentVertexNormal);
    vec3 viewDirection = normalize(viewPosition - fragmentPosition);

    // Keep a subtle global ambient term so the scene stays readable
    // without washing out the wall, desk, and lamp.
    vec3 ambient = vec3(0.015) + material.ambientColor *
                   material.ambientStrength * 0.20;
    vec3 diffuse = vec3(0.0);
    vec3 specular = vec3(0.0);

    for (int i = 0; i < TOTAL_LIGHTS; i++)
    {
        LightSource light = lightSources[i];
        if (length(light.diffuseColor) < 0.001)
        {
            continue;
        }

        vec3 lightDirection = normalize(light.position - fragmentPosition);
        float lightAmount = max(dot(normal, lightDirection), 0.0);

        ambient += light.ambientColor * material.ambientColor * 0.15;
        diffuse += lightAmount * light.diffuseColor * material.diffuseColor;

        // Specular reflections are only visible on illuminated surfaces.
        if (lightAmount > 0.0)
        {
            vec3 reflected = reflect(-lightDirection, normal);
            float highlight = pow(max(dot(viewDirection, reflected), 0.0),
                                  max(light.focalStrength, 1.0));
            specular += highlight * light.specularIntensity *
                        material.shininess * material.specularColor *
                        light.specularColor;
        }
    }

    // Texture colors are affected by ambient and diffuse light, while
    // the specular highlight is reflected from the surface itself.
    vec3 finalColor = (ambient + diffuse) * surfaceColor.rgb + specular;
    outFragmentColor = vec4(clamp(finalColor, 0.0, 1.0), surfaceColor.a);
}
